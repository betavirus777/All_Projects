<?php

	require_once "/home1/enginee8/public_html/vb-iet/include/helpers.php";

    logout();

    render('display.php', array('message' => 'Logged out Successfully.'));

?>
