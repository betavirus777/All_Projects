<?php 
	
	require_once "/home1/enginee8/public_html/vb-iet/include/helpers.php";
	
	render('main.php', array('title' => ''));
	
?>