<?php

	require_once "/home1/enginee8/public_html/vb-iet/include/config.php";
	
	redirect('../public');
	exit;
?>