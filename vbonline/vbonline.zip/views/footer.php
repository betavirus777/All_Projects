

		<script src="/public/js/jquery-3.1.0.min.js"></script>
		 <script src="/public/js/bootstrap.min.js"></script>
	</body>
</html>